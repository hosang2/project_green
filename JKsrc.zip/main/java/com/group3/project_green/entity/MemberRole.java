package com.group3.project_green.entity;

public enum MemberRole {
    USER, ADMIN
}
