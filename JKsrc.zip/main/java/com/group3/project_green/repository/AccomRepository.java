package com.group3.project_green.repository;

import com.group3.project_green.entity.Accom;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AccomRepository extends JpaRepository<Accom, Long> {
}
