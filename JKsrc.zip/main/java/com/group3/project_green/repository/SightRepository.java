package com.group3.project_green.repository;


import com.group3.project_green.entity.Sights;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SightRepository extends JpaRepository<Sights, Long> {
}
