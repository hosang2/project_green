package com.group3.project_green;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectGreenApplicationTests {

    @Test
    void contextLoads() {
    }

}
